const express=require('express')
const app=express()
const cors=require('cors')
const dotenv=require('dotenv')
const mongoose=require('mongoose')

//Cofgig Env
dotenv.config({path:'./config/config.env'})

const hostname=process.env.Host_NAME;
const port=process.env.PORT;

//configure Cors
app.use(cors());


//Accect From Data
app.use(express.json())
app.use(express.urlencoded({extended:false}))

//Connect To Mongoose
mongoose.connect(process.env.MONGODB_LOCAL_DB,{
    useUnifiedTopology:true,
    useNewUrlParser:true,
    useCreateIndex:true
}).then(()=>{
    console.log("Connect");
})


//Configure Route
app.use('/api',require('./router/apiRouter'))

app.get('/',(req,res)=>{
    res.send('Hello')
})

app.listen(port,()=>{
        console.log(`Express Server Run At http://${port}`);
})
