const express=require('express')
const router=express.Router();
const Contact=require('../model/contact')

//Create Contact
router.post('/contact',async(req,res)=>{
    let newContact={
        firstname:req.body.firstname,
        lastname:req.body.lastname,
        email:req.body.email,
        officephone:req.body.officephone,
        mobilephone:req.body.mobilephone,
        org_name:req.body.org_name,
        org_type:req.body.org_type,
        address:req.body.address
    }
    console.log(newContact);
    try {
        let contact=new Contact(newContact);
        contact=await contact.save()
        console.log(contact);
        res.status(200).json(contact)
        
    } catch (err) {
        console.log(err);
        res.status(500).json({
            msg:err.message
        })
    }
})

//Update Contact
router.post('/contact/:id',async(req,res)=>{
    let contactId=req.params.id;
    let updateContact={
        firstname:req.body.firstname,
        lastname:req.body.lastname,
        email:req.body.email,
        officephone:req.body.officephone,
        mobilephone:req.body.mobilephone,
        org_name:req.body.org_name,
        org_type:req.body.org_type,
        address:req.body.address
    }
    try {
        let contact=await Contact.findById(contactId);
        if(contact){
            contact=await Contact.findByIdAndUpdate(contactId,{
                $set:updateContact
            },{new:true})
            res.status(200).json(contact)
        }
        else{
            res.status(500).json({
                msg:'product is not update',
                contact
            })
        }       
    } catch (err) {
        console.log(err);
        res.status(500).json({
            msg:err.message
        })
    }
})


//Get All Contact
router.get('/contact',async(req,res)=>{
    try {
        let contact=await Contact.find();
        res.status(200).json(contact)
    } catch (err) {
        console.log(err);
        res.status(500).json({
            msg:err.message
        })
    }
})

//Get Single Contact
router.get('/contact/:id',async(req,res)=>{
    let contactId=req.params.id;
    try {
        let contact=await Contact.findById(contactId);
        res.status(200).json(contact)
    } catch (err) {
        console.log(err);
        res.status(500).json({
            msg:err.message
        })
    }
})

//Delete Contact
router.delete('/contact/:id',async(req,res)=>{
    let contactId=req.params.id;
    try {
        let contact=await Contact.findByIdAndDelete(contactId);
        res.status(200).json(contact)
        
    } catch (err) {
        console.log(err);
        res.status(500).json({
            msg:err.message
        })
    }
})

module.exports=router;