const mongoose=require('mongoose')

let contctSchema=new mongoose.Schema({
    firstname:{
        type:String,
        required:true
    },
    lastname:{
        type:String,
        required:true
    },
    email:{
        type:String,
        required:true
    },
    officephone:{
        type:Number,
        required:true
    },
    mobilephone:{
        type:Number,
        required:true
    },
    org_name:{
        type:String,
        required:true
    },
    org_type:{
        type:String,
        required:true
    },
    address:{
        type:String,
        required:true
    }
});

let Contact=mongoose.model('contact',contctSchema)
module.exports=Contact;