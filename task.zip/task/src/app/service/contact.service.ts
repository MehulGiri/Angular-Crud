import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Contact } from '../model/Contact';

@Injectable({
  providedIn: 'root'
})
export class ContactService {

  constructor(private httpclient:HttpClient) { }

  //Add Contact
  public addContact(contact):Observable<Contact>{
   let urldata="http://localhost:3000/api/contact/"
    return this.httpclient.post<Contact>(urldata,contact)
  }

  //Get All Product
    public getAllContact():Observable<Contact[]>{
      let dataUrl="http://localhost:3000/api/contact/"
      return this.httpclient.get<Contact[]>(dataUrl)
    }

  // Get A Single Contact
    public getContact(contactId):Observable<Contact>{
      let dataUrl=`http://localhost:3000/api/contact/${contactId}`;
      return this.httpclient.get<Contact>(dataUrl)
    }

  //Update Contact
  public UpdateContact(contactId,contact):Observable<Contact>{
    let dataUrl=`http://localhost:3000/api/contact/${contactId}`;
    return this.httpclient.post<Contact>(dataUrl,contact)
  }
  //Delete Conatct
  public deleteContact(contactId):Observable<Contact>{
    let dataUrl=`http://localhost:3000/api/contact/${contactId}`;
    return this.httpclient.delete<Contact>(dataUrl)
  }  


}
