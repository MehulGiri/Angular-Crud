import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ListContactComponent } from './list-contact/list-contact.component';
import { UpdateContactComponent } from './update-contact/update-contact.component';

const routes: Routes = [
    {path:'list-record',component:ListContactComponent},
    {path:'update/:id',component:UpdateContactComponent}  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
