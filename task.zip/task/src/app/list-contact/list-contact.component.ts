import { Component, OnInit } from '@angular/core';
import { Contact } from '../model/Contact';
import { ContactService } from '../service/contact.service';

@Component({
  selector: 'app-list-contact',
  templateUrl: './list-contact.component.html',
  styleUrls: ['./list-contact.component.css']
})
export class ListContactComponent implements OnInit {

  public contacts:Contact[]=[];

  constructor(private contactService:ContactService) { }

  ngOnInit(): void {

      this.contactService.getAllContact().subscribe((data)=>{
        this.contacts=data
      },(err)=>{
          console.log(err.message);
          
      })
  }
  DeleteContact(contactId){
      this.contactService.deleteContact(contactId).subscribe(()=>{
        
      })
  }

}
