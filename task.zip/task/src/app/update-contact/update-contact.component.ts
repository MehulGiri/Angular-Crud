import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, ParamMap } from '@angular/router';
import { Contact } from '../model/Contact';
import { ContactService } from '../service/contact.service';

@Component({
  selector: 'app-update-contact',
  templateUrl: './update-contact.component.html',
  styleUrls: ['./update-contact.component.css']
})
export class UpdateContactComponent implements OnInit {
  contact: FormGroup;

  public contactId:String;
  public selectedContact:Contact;
  constructor(private activatedRoute:ActivatedRoute,private contactService:ContactService) { }

  ngOnInit(): void {
    this.contact=new FormGroup({
      firstname:new FormControl('',Validators.required),
      lastname:new FormControl('',Validators.required),
      email:new FormControl('',[Validators.required,Validators.email]),
      officephone:new FormControl('',[Validators.maxLength(10),Validators.minLength(10)]),
      mobilephone:new FormControl('',[Validators.maxLength(10),Validators.minLength(10)]),
      org_name:new FormControl('',Validators.required),
      org_type:new FormControl('',Validators.required),
      address:new FormControl('',)      

    })

    this.activatedRoute.paramMap.subscribe((param:ParamMap)=>{
      this.contactId=param.get('id')
    })
      this.contactService.getContact(this.contactId).subscribe((data)=>{
        this.selectedContact=data
      },(err)=>{
          console.log(err.message);
          
      })

  }

  updateContact(){
    // console.log(this.contactId);
    // console.log(this.selectedContact);
    
    
      this.contactService.UpdateContact(this.contactId,this.contact.value).subscribe((data)=>{
          console.log(data);    
      },(err)=>{
          console.log(err);
          
      })
  }

}
