export interface Contact{
    firstname:string,
    lastname:string,
    email:string,
    officephone:number,
    mobilephone:number,
    org_name:string,
    org_type:string
    address:string
}